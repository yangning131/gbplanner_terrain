#ifndef POINT_H_
#define POINT_H_
#define INTPOINT IntPoint

/*new value type : ption */
class IntPoint {
public:
  IntPoint() : x(0), y(0) {}
  IntPoint(int _x, int _y) : x(_x), y(_y) {}
  int x,y;
};

#endif /* POINT_H_ */
