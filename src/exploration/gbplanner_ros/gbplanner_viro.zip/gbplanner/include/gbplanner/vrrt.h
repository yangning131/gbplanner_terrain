#ifndef VRRT_H
#define VRRT_H

#include <ros/ros.h>
#include <visualization_msgs/Marker.h>
#include <geometry_msgs/PoseStamped.h>
#include <geometry_msgs/PoseWithCovarianceStamped.h>
#include <pcl_ros/point_cloud.h>

#include <vector>

namespace explorer {
namespace gbplanner {
	
struct Point{
	double x,y,z;
};

struct Node{
	bool is_free;
	bool is_voronoi;
	Point position;
};

struct node{
	Point point;
	int node_id;
	int parent_id;
};
	
class VRRT{
	
public:
	//construction function
	VRRT();
	
	//deconstruction function
	~VRRT();
	
	//get start point
	Point get_start_point();
	
	//get goal point
	Point get_goal_point();
	
	//get 2d map from 2d pointcloud
	bool init_vmap(std::vector< std::vector<Node> >& vmap);
	
	//explore_map is used for remeber which voronoi edge grid has been used, true means has been used berore, false means not yet
	void init_explore_map( std::vector< std::vector<Node> >& vmap, std::vector< std::vector<bool> >& explored_map);
	
	//find the nearst but no collision voronoi node to a 3D point
	std::pair<int,int> find_v_node(Point& point, std::vector< std::vector<Node> >& vmap);
	
	//move forward using a box with length and width, any voronoi node crossing with that box will be stored and used for optimization
	std::vector< std::pair<int,int> > get_v_node(std::pair<int,int>& N, std::vector< std::vector<Node> >& vmap, std::vector< std::vector<bool> >& explore_map, double& length, double width);
	
	//find the best basic node N among current search temp, point represent the mission goal
	bool get_best_node(std::vector< std::pair<int,int> >& temp, Point& point, std::pair<int,int>& N);
	
	//the voronoi edge node has to be removed from temp beform put into branch
	void remove_node_from_temp(std::pair<int,int>& N, std::vector< std::pair<int,int> >& temp);
	
	//get random particles around basic node N
	std::vector<Point> get_particles(std::pair<int,int>& N, int& num, double& radius_x, double& radius_y, double& limited_min_z, double& limited_max_z);
	
	//find the bast particle for random tree growth, if return true, then point is the best particle, and the parent_id is its' parent node id
	bool get_best_particle(std::vector<node>& tree, std::vector<Point>& particles, bool& new_branch, double& collision_radius, Point& point, int& parent_id);
	
	//set to random tree
	void set_to_tree(std::vector<node>& tree, Point& point, int parent_id);
	
	//if we can get a best particle to grow the random tree, then check whether there are still some node in temp, if it is, store them into branch
	void set_node_to_branch(std::vector< std::pair<int,int> >& branch,std::vector< std::pair<int,int> >& temp);
	
	//check whether close enough to mission gaol
	bool is_finish(std::vector<node>& tree, Point& point, double& collision_radius);
	
	//get final path by quring from the last point of random tree backword to the first point
	void get_final_path(std::vector<node>& tree, std::vector<Point>& path);
	
	//path smoothing algorithm
	void smoothing(std::vector<Point>& path, double& collision_radius, double step, int iterations, std::vector<Point>& smooth_path);
	
	//extract voronoi edge node from vmap
	void get_voronoi_edge(std::vector< std::vector<Node> >& vmap, std::vector< Point >& vedge);
	
	//distribute particles along voronoi diagram edge, d_x,d_y is the radius for particles distribute
// 	void random_particles(std::vector< Point >& edge, int& num, double r_x, double r_y, std::vector<Point>& particles);
	
	void initializeMarkers(visualization_msgs::Marker& start_marker, visualization_msgs::Marker& goal_marker, visualization_msgs::Marker& particles_marker,
				visualization_msgs::Marker& tree_marker, visualization_msgs::Marker& path_marker, visualization_msgs::Marker& smooth_marker,
				visualization_msgs::Marker& map2D_marker, visualization_msgs::Marker& vedge_marker, std::string& frame_id);
	
	void pub_start(visualization_msgs::Marker& marker, Point& point);
	void pub_goal(visualization_msgs::Marker& marker, Point& point);
	void pub_particles(visualization_msgs::Marker& marker, std::vector<Point>& particles);
	void pub_tree(visualization_msgs::Marker& marker, std::vector<node>& tree);
	void pub_path(visualization_msgs::Marker& marker, std::vector<Point>& path);
	void pub_smooth_path(visualization_msgs::Marker& marker, std::vector<Point>& smooth_path);
	void pub_map2D(visualization_msgs::Marker& marker, std::vector< std::vector<Node> >& vmap);
	void pub_vedge(visualization_msgs::Marker& marker, std::vector<Point>& vedge);
	void pub_explore(std::vector<Point>& vedge, std::vector< std::vector<bool> >& explore_map);
	
	void pub_2D_point(std::string& frame_id);
	
	bool initional_pos_flag,mission_goal_flag;
	
private:
	
	//callback function of the Subscriber
	//subscribe the OctoMap to get the 3d voxel center points
	void get_point_cloud(const pcl::PointCloud<pcl::PointXYZ>::ConstPtr& pointcloud);
	
	//subscribe to get the start point
	void get_initional_pos(const geometry_msgs::PoseWithCovarianceStampedConstPtr &msg);
	
	//subscribe to get the mission gaol
	void get_mission_goal(const geometry_msgs::PoseStampedConstPtr &msg);
	
	//collision checking algorithm, true means there is a collision, false means no collision
	bool collisiong_check(Point& point1, Point& point2, double& radius);
	
	//check whether it is out of boundary, true means out and false means inside
	bool check_boundary(Point& point);
	
	//measure the square distance between two 2D point
	double get_Euclidean_distance(int& x1, int& y1, int& x2, int& y2);
	
	//measure the square distance between two point
	double get_Euclidean_distance(Point& point1,Point& point2);
	
	//get the distance from point to line in 3d space, the line represented by two point
	double get_dist_point_to_line(Point& point, Point& line_point1, Point& line_point2);
	
	ros::NodeHandle nh_;
	ros::Subscriber subMissionGoal_;
	ros::Subscriber subInitionalpos_;
	ros::Subscriber subOctomapCenterCloud_;
	
	ros::Publisher start_pub_;
	ros::Publisher goal_pub_;
	ros::Publisher particles_pub_;
	ros::Publisher tree_pub_;
	ros::Publisher path_pub_;
	ros::Publisher smooth_path_pub;
	ros::Publisher map2D_pub_;
	ros::Publisher vedge_pub_;
	ros::Publisher explore_pub_;
	ros::Publisher cloud2D_pub_;
	
	Point initional_pos_,mission_goal_;
	
	pcl::PointCloud<pcl::PointXYZ>::Ptr octomap_center_cloud_;
	pcl::PointCloud<pcl::PointXYZ>::Ptr cloud_2d_;
	
	//The boundary of 3d octomap center point
	double min_length_,max_length_,min_width_,max_width_,min_height_,max_height_;
	
	//the resolution of the octomap and the 2d map
	double resolution_;
	
	//the 2d map hight
	double hight_;
	
	//false means have not get the octomap, so can not receive the initional_pos_ and mission_goal_
	bool boundary_flag_;
	
};//end class
	
}//end namespace
}

#endif