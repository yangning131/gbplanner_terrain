#ifndef DYNAMICVORONOI_H_
#define DYNAMICVORONOI_H_

#include <stdlib.h>
#include <stdio.h>
#include <limits.h>
#include <queue>

#include <gbplanner/bucketedqueue.h>
#include <gbplanner/vrrt.h>

namespace explorer {
namespace gbplanner {

//! A DynamicVoronoi object computes and updates a distance map and Voronoi diagram.
class DynamicVoronoi {

public:

	DynamicVoronoi();
	~DynamicVoronoi();

	//! Initialization with a given binary map(occupancy map:false==free, true==occupied)
	void initializeMap(std::vector< std::vector<Node> >& vmap);
	//! Check the difference when receive a new local gridMap which size is xize_x,size_y and left corner is x_min,y_min
	void mapupdate(int x_min, int y_min, int size_x, int size_y, bool** _newgridMap);
	//! add an obstacle at the specified cell coordinate
	void occupyCell(int x, int y);
	//! remove an obstacle at the specified cell coordinate
	void clearCell(int x, int y);
	//!set (x,y) to be occupied in gridmap and add (x,y) into the addList
	void setObstacle(int x, int y);
	//!set (x,y) to be free in gridmap and add (x,y) into the removeList
	void removeObstacle(int x, int y);
	//!deal with addList and removeList ,add that cell to bucket (open) for proporgate
	void commitAndColorize(bool updateRealDist = true);
	//! update distance map and Voronoi diagram to reflect the changes
	void brushfire(bool updateRealDist = true);
	//! prune the Voronoi diagram
	void prune();
	//! returns whether the specified cell is part of the (pruned) Voronoi graph
	bool isVoronoi(int x, int y);
	//! checks whether the specficied location is occupied
	bool isOccupied(int x, int y);


private:
	struct dataCell {
		float dist;
		int voronoi;
		char queueing;
		int obstX;    //the x coordinate of closest obstacle
		int obstY;    //the y coordinate of closest obstacle
		bool needsRaise;  //true if it is remove obstacle
		int sqdist;
	};

	typedef enum {
		voronoiKeep = -4,
		freeQueued = -3,
		voronoiRetry = -2,
		voronoiPrune = -1,
		free = 0,
		occupied = 1  //obstacle
	} State;
	typedef enum {
		fwNotQueued = 1,
		fwQueued = 2,    // the first time to proporgate
		fwProcessed = 3,
		bwQueued = 4,    //remove obstacle, the second time to proporgate
		bwProcessed = 1
	} QueueingState;
	typedef enum {
		invalidObstData = SHRT_MAX / 2    //initionalized or obstacle removed
	} ObstDataState;
	typedef enum {
		pruned, keep, retry
	} markerMatchResult;

	// methods
	inline void checkVoro(int x, int y, int nx, int ny, dataCell& c, dataCell& nc);
	inline void reviveVoroNeighbors(int &x, int &y);

	inline bool isOccupied(int &x, int &y, dataCell &c);
	inline markerMatchResult markerMatch(int x, int y);

	// queues
	BucketPrioQueue open;
	std::queue<INTPOINT> pruneQueue;
	std::vector<INTPOINT> removeList;   //vector stored point that will cleared as free
	std::vector<INTPOINT> addList;      //vector stored point that will be set to obstacle
	std::vector<INTPOINT> lastObstacles;

	// maps
	dataCell** data;
	bool** gridMap;

	// parameters
	int padding;
	double doubleThreshold;

	int sizeX,sizeY;
};

}//end namespace global_planner

}
#endif /* DYNAMICVORONOI_H_ */
