#include <ros/ros.h>
#include <visualization_msgs/Marker.h>
#include <geometry_msgs/PoseStamped.h>
#include <geometry_msgs/PoseWithCovarianceStamped.h>
#include <pcl_ros/point_cloud.h>

#include <pcl/impl/point_types.hpp>
#include <pcl/octree/octree_impl.h>
#include <pcl/octree/octree_search.h>

#include <pcl/kdtree/kdtree.h>
#include <pcl/kdtree/kdtree_flann.h>

#include <iostream>
#include <stdlib.h> 
#include <time.h>
#include <boost/iterator/iterator_concepts.hpp>

#include <gbplanner/vrrt.h>

using namespace std;

namespace explorer {
namespace gbplanner {

//construction function
VRRT::VRRT(){
	
	subInitionalpos_ = nh_.subscribe<geometry_msgs::PoseWithCovarianceStamped>("/initialpose", 1, &VRRT::get_initional_pos, this);
	subMissionGoal_ = nh_.subscribe<geometry_msgs::PoseStamped>("/move_base_simple/goal", 1, &VRRT::get_mission_goal, this);
	subOctomapCenterCloud_ = nh_.subscribe< pcl::PointCloud<pcl::PointXYZ> >("/occ_vox_center",1,&VRRT::get_point_cloud,this);
	
	start_pub_ = nh_.advertise< visualization_msgs::Marker >("/start_point",1);
	goal_pub_ = nh_.advertise< visualization_msgs::Marker >("/mission_goal",1);
	particles_pub_ = nh_.advertise<visualization_msgs::Marker>("particles",1);
	tree_pub_ = nh_.advertise<visualization_msgs::Marker>("tree",1);
	path_pub_ = nh_.advertise<visualization_msgs::Marker>("path",1);
	smooth_path_pub = nh_.advertise<visualization_msgs::Marker>("smooth_path",1);
	map2D_pub_ = nh_.advertise<visualization_msgs::Marker>("map2D",1);
	vedge_pub_ = nh_.advertise<visualization_msgs::Marker>("vedge",1);
	explore_pub_ = nh_.advertise<visualization_msgs::Marker>("explore_map",1);
	
	cloud2D_pub_ = nh_.advertise< pcl::PointCloud<pcl::PointXYZ> >("point_2D", 1);
	
	octomap_center_cloud_ = pcl::PointCloud<pcl::PointXYZ>::Ptr(new pcl::PointCloud<pcl::PointXYZ>);
	cloud_2d_ = pcl::PointCloud<pcl::PointXYZ>::Ptr(new pcl::PointCloud<pcl::PointXYZ>);
	
	boundary_flag_ = initional_pos_flag = mission_goal_flag = false;
	min_length_ = max_length_ = min_width_ = max_width_ = min_height_ = max_height_ = 0;
	
	nh_.param<double>("/vrrt/resolution", resolution_, 0.1);
	nh_.param<double>("/vrrt/2d_hight", hight_, 1);		//creat voronoi digram in that level
	
// 	set time to be the seed
	srand((unsigned int)time(NULL));
}

//deconstruction function
VRRT::~VRRT(){
}

//get start point
Point VRRT::get_start_point(){
	return initional_pos_;
}
	
//get goal point
Point VRRT::get_goal_point(){
	return mission_goal_;
}

//get 2d map from 2d pointcloud
bool VRRT::init_vmap(std::vector< std::vector<Node> >& vmap){
	
	if(boundary_flag_){
		if(cloud_2d_->points.empty()){
			ROS_ERROR("There are no points for 2D map creating in the specified hight !");
			return false;
		}
		
		if(vmap.empty()){
			
			int size_x = (int)( ( (max_length_ - min_length_) / resolution_ ) + 0.5 );
			int size_y = (int)( ( (max_width_ - min_width_) / resolution_ ) + 0.5 );
		
			vector<Node> column;
			Node N;
			N.is_free = true;
			N.is_voronoi = false;
			N.position.z = cloud_2d_->points[0].z;
			
			for(int i=0;i<=size_x;i++){
				column.clear();
				N.position.x = i * resolution_ + min_length_;
				for(int j=0;j<=size_y;j++){
					N.position.y = j * resolution_ + min_width_;
					column.push_back(N);
				}
				vmap.push_back(column);
			}
			
			int index_x,index_y;
			for(int i=0;i<cloud_2d_->points.size();i++){
				index_x = (int)( ( ( cloud_2d_->points[i].x - min_length_ ) / resolution_ ) + 0.5);
				index_y = (int)( ( ( cloud_2d_->points[i].y - min_width_ ) / resolution_ ) + 0.5);
				vmap[index_x][index_y].is_free = false;
			}
			
			if(vmap.size()){
				ROS_INFO("Create 2D map successfully, waiting for create voronoi diagram...");
				return true;
			}else{
				ROS_WARN("Could not create 2D map !");
				return false;
			}
		}
	}
	return false;
}

//explore_map is used for remeber which voronoi edge grid has been used
void VRRT::init_explore_map( std::vector< std::vector<Node> >& vmap, std::vector< std::vector<bool> >& explored_map){
	
	if(explored_map.size())
		explored_map.clear();
	
	std::vector<bool> column;
	
	for(int i=0;i<vmap.size();i++){
		column.clear();
		for(int j=0;j<vmap[i].size();j++){
			column.push_back(false);
		}
		explored_map.push_back(column);
	}
}

//find the nearst but no collision voronoi node to a 3D point
std::pair<int,int> VRRT::find_v_node(Point& point, std::vector< std::vector<Node> >& vmap){
		
	std::vector< std::pair<int,int> > open;
	std::pair<int,int> temp;
	bool** flag_map;
	flag_map = new bool*[vmap.size()];
	for (int i=0;i<vmap.size();++i){
		flag_map[i] = new bool[vmap[i].size()];
	}
	
	for (int i=0;i<vmap.size();++i){
		for(int j=0;j<vmap[i].size();j++){
			flag_map[i][j] = false;
		}
	}
	
	int vx = (int)( ( (point.x - min_length_ ) / resolution_ ) + 0.5);
	int vy = (int)( ( ( point.y - min_width_ ) / resolution_ ) + 0.5);
	
	if(vmap[vx][vy].is_voronoi == true){
		temp = std::pair<int,int>(vx,vy);
		return temp;
	}else{
		open.push_back(std::pair<int,int>(vx,vy));
		flag_map[vx][vy] = true;
	
		int x,y,nx,ny;
		while(!open.empty()){
			
			x = open.front().first;
			y = open.front().second;
			open.erase(open.begin());
			
			for(int dx=-1;dx<=1;dx++){
				nx = x + dx;
				if(nx<0||nx>=vmap.size())
					continue;
				for(int dy=-1;dy<=1;dy++){
					if( (dx==0)&&(dy==0) )
						continue;
					ny = y + dy;
					if(ny<0||ny>=vmap[0].size())
						continue;
					if(flag_map[nx][ny] == false){
						if(vmap[nx][ny].is_free == false)
							continue;
						if(vmap[nx][ny].is_voronoi == true){
							temp = std::pair<int,int>(nx,ny);
							return temp;
						}
						open.push_back(std::pair<int,int>(nx,ny));
						flag_map[nx][ny] = true;
					}
				}
			}
		}
	}
	ROS_ERROR("No valid start point in voronoi map !");
	return temp;
}

//move forward using a box with length and width, any voronoi node crossing with that box will be stored and used for optimization
std::vector< std::pair<int,int> > VRRT::get_v_node(std::pair<int,int>& N, std::vector< std::vector<Node> >& vmap, std::vector< std::vector<bool> >& explore_map, double& length, double width){
	
	std::vector< std::pair<int,int> > temp;
	
	int rx = (int)(length / resolution_ + 0.5);
	int ry = (int)(width / resolution_ + 0.5);
	int nx, ny;
	
	for(int dx=-rx;dx<=rx;dx++){
		
		nx = N.first + dx;
		if( (nx<0)||(nx>=vmap.size()) )
			continue;
		
		for(int dy=-ry;dy<=ry;dy++){
			
			if( (dx==0)&&(dy==0) )
				continue;
			
			ny = N.second + dy;
			if( (ny<0)||(ny>=vmap[0].size()) )
				continue;
			
			if(vmap[nx][ny].is_voronoi == true){
				
// 				cout<<"This is a test !"<<endl;
				
				if(explore_map[nx][ny] == false){
					if((dx==-rx)||(dx==rx)||(dy==-ry)||(dy==ry)){
						temp.push_back(std::pair<int,int>(nx,ny));
					}
					explore_map[nx][ny] = true;
				}
			}
		}
	}
	
	return temp;
}
	
//find the best basic node N among current search temp, point represent the mission goal
bool VRRT::get_best_node(std::vector< std::pair<int,int> >& temp, Point& point, std::pair<int,int>& N){
	
	if(temp.size()){
		double dist = 100000000;
		double dist_temp;
		
		std::pair<int,int> temp_node;
		
		int vx = (int)( ( (point.x - min_length_ ) / resolution_ ) + 0.5);
		int vy = (int)( ( ( point.y - min_width_ ) / resolution_ ) + 0.5);
		
		for(int i=0;i<temp.size();i++){
			
			dist_temp = get_Euclidean_distance(temp[i].first,temp[i].second,vx,vy);
			
			if(dist_temp < dist){
				temp_node = temp[i];
				dist = dist_temp;
			}
		}
		
		N = temp_node;
		return true;
	}else{
		N.first = 0;
		N.second = 0;
		return false;
	}
}

//the voronoi edge node has to be removed from temp beform put into branch
void VRRT::remove_node_from_temp(std::pair<int,int>& N, std::vector< std::pair<int,int> >& temp){
	
	if(temp.size()){
		for(int i=0;i<temp.size();i++){
			if( (temp[i].first == N.first)&&(temp[i].second == N.second) ){
				temp.erase(temp.begin()+i);
			}
		}
	}
}
	
//get random particles around basic node N
std::vector<Point> VRRT::get_particles(std::pair<int,int>& N, int& num, double& radius_x, double& radius_y, double& limited_min_z, double& limited_max_z){
	
	std::vector<Point> particles;
	Point p,point1,point2;
	
	point1.x = N.first * resolution_ + min_length_;
	point1.y = N.second * resolution_ + min_width_;
	
	int range_x = int( (2 * radius_x)  / resolution_ );
	int range_y = int( (2 * radius_y)  / resolution_ );
	int range_z = int( (limited_max_z - limited_min_z) / resolution_ );
	
	for(int i=0;i<num;i++){
		
		p.x = point1.x + ( rand() % range_x ) * resolution_ - radius_x;
		p.y = point1.y + ( rand() % range_y ) * resolution_ - radius_y;
		p.z = ( rand() % range_z ) * resolution_ + limited_min_z;
		
		particles.push_back(p);
	}
	
	//remove the point out of boundary
	for(int i=0;i<particles.size();i++){
		if( (particles[i].x<min_length_)||(particles[i].x>max_length_)||(particles[i].y<min_width_)||(particles[i].y>max_width_) ){
			particles.erase(particles.begin()+i);
			i--;
		}
	}
	
	//remove the point embedded in obstacles
	double dist;
	double square_resolution = resolution_*resolution_;
	for(int i=0;i<octomap_center_cloud_->points.size();i++){
		if( (abs(octomap_center_cloud_->points[i].x-point1.x)<radius_x)&&(abs(octomap_center_cloud_->points[i].y-point1.y)<radius_y) ){
			point2.x = octomap_center_cloud_->points[i].x;
			point2.y = octomap_center_cloud_->points[i].y;
			point2.z = octomap_center_cloud_->points[i].z;
			for(int j=0;j<particles.size();j++){
				dist = get_Euclidean_distance(point2,particles[j]);
				if( dist <= square_resolution ){
					particles.erase(particles.begin()+j);
					j--;
				}
			}
		}	
	}
	
	return particles;
}
	
//find the bast particle for random tree growth, if return true, then point is the best particle, and the parent_id is its' parent node id
bool VRRT::get_best_particle(std::vector<node>& tree, std::vector<Point>& particles, bool& new_branch, double& collision_radius, Point& point, int& parent_id){
	
	if(particles.empty()){
		return false;
	}
	
	node nearst_node;
	
	if(new_branch){		//for the new branch particles, a nearst node for random tree new branch root has to be selected
		Point sum, average;
		for(int i=0;i<particles.size();i++){
			sum.x += particles[i].x;
			sum.y += particles[i].y;
			sum.z += particles[i].z;
		}
		average.x = sum.x / particles.size();
		average.y = sum.y / particles.size();
		average.z = sum.z / particles.size();
		
		double dist,dist_temp;
		dist = 100000000;
		for(int i=0;i<tree.size();i++){
			dist_temp = get_Euclidean_distance(tree[i].point,average);
			if(dist_temp<dist){
				dist = dist_temp;
				nearst_node.point.x = tree[i].point.x;
				nearst_node.point.y = tree[i].point.y;
				nearst_node.point.z = tree[i].point.z;
				nearst_node.node_id = tree[i].node_id;
				nearst_node.parent_id = tree[i].parent_id;
			}
		}
	}else{		//if keep going forward, just use the last random tree node
		nearst_node.point.x = tree.back().point.x;
		nearst_node.point.y = tree.back().point.y;
		nearst_node.point.z = tree.back().point.z;
		nearst_node.node_id = tree.back().node_id;
		nearst_node.parent_id = tree.back().parent_id;
	}
	
	std::vector<double> forward_dist,goal_dist,obst_dist,cost;
	double distance,min_f_dist,max_f_dist,min_g_dist,max_g_dist,min_o_dist,max_o_dist;
	min_f_dist = min_g_dist = min_o_dist = 100000000;
	max_f_dist = max_g_dist = max_o_dist = 0;
	
	//find the distance move from nearst_node to each particle, the bigger distance, the better value
	for(int i=0;i<particles.size();i++){
		distance = get_Euclidean_distance(particles[i],nearst_node.point);
		
		forward_dist.push_back(distance);
		if(distance<min_f_dist)
			min_f_dist = distance;
		if(distance>max_f_dist)
			max_f_dist = distance;
	}
	
	//get the distance from each particle to mission goal, the smaller distance, the better value
	for(int i=0;i<particles.size();i++){
		distance = get_Euclidean_distance(particles[i],mission_goal_);
		goal_dist.push_back(distance);
		if(distance<min_g_dist)
			min_g_dist = distance;
		if(distance>max_g_dist)
			max_g_dist = distance;
	}
	
	//create an kdtree to get the distance for each particle to its' nearst 3d obst point, the bigger distance, the better value
	pcl::PointCloud<pcl::PointXYZ>::Ptr cloud(octomap_center_cloud_);
	pcl::KdTreeFLANN<pcl::PointXYZ> kdtree;
	kdtree.setInputCloud(cloud);
	
	pcl::PointXYZ searchPoint;
	std::vector<int> point_index;
	std::vector<float> point_dist;
	for(int i=0;i<particles.size();i++){
	
		searchPoint.x = particles[i].x;
		searchPoint.y = particles[i].y;
		searchPoint.z = particles[i].z;
		point_index.clear();
		point_dist.clear();
		if(kdtree.nearestKSearch(searchPoint,1,point_index,point_dist)>0){
			distance = (double)( point_dist.front() );
			obst_dist.push_back( distance );
			if(distance<min_o_dist)
				min_o_dist = distance;
			if(distance>max_o_dist)
				max_o_dist = distance;
		}
	}
	
	//chenge the direction to big value
	double temp;
	for(int i=0;i<goal_dist.size();i++){
		temp = goal_dist[i];
		goal_dist[i] = 1/temp;
	}
	temp = min_g_dist;
	min_g_dist = 1/max_g_dist;
	max_g_dist = 1/temp;
	
	//normalization process
	for(int i=0;i<particles.size();i++){
		
		temp = ( forward_dist[i] - min_f_dist ) / ( max_f_dist - min_f_dist );
		forward_dist[i] = temp;
		
		temp = ( goal_dist[i] - min_g_dist ) / ( max_g_dist - min_g_dist );
		goal_dist[i] = temp;
		
		temp = ( obst_dist[i] - min_o_dist ) / ( max_o_dist - min_o_dist );
		obst_dist[i] = temp;
	}
	
	//collision checking and compute the cost for each particle
	double value;
	for(int i=0;i<particles.size();i++){
		
		if(collisiong_check(nearst_node.point,particles[i],collision_radius)){
			cost.push_back(-1);
		}else{
			value = forward_dist[i] + goal_dist[i] + obst_dist[i];
			cost.push_back(value);
		}
	}
	
	//find out the particle with the bigest value
	value = cost.front();
	int index = 0;
	for(int i=1;i<cost.size();i++){
		if(cost[i]>value){
			value = cost[i];
			index = i;
		}
	}
	
	if(value<0){
		return false;
	}else{
		point.x = particles[index].x;
		point.y = particles[index].y;
		point.z = particles[index].z;
		
		parent_id = nearst_node.node_id;
		
		return true;
	}
}
	
//set to random tree
void VRRT::set_to_tree(std::vector<node>& tree, Point& point, int parent_id){
	
	node n;
	n.point.x = point.x;
	n.point.y = point.y;
	n.point.z = point.z;
	n.node_id = tree.size();
	n.parent_id = parent_id;
	
	tree.push_back(n);
}

//if we can get a best particle to grow the random tree, then check whether there are still some node in temp, if it is, store them into branch
void VRRT::set_node_to_branch(std::vector< std::pair<int,int> >& branch,std::vector< std::pair<int,int> >& temp){
	
	if(temp.size()){
		
		for(int i=0;i<temp.size();i++){
			branch.push_back(temp[i]);
		}
	}
	
	temp.clear();
}
	
//check whether close enough to mission gaol
bool VRRT::is_finish(std::vector<node>& tree, Point& point, double& collision_radius){
	
	bool reache_goal = collisiong_check(tree.back().point, point,collision_radius);
	if(!reache_goal){
		return true;
	}else{
		return false;
	}
}
	
//get final path by quring from the last point of random tree backword to the first point
void VRRT::get_final_path(std::vector<node>& tree, std::vector<Point>& path){
	
	std::vector<int> path_node_id;
	path_node_id.push_back(tree.back().node_id);
	
	while(path_node_id.front() != 0){
        path_node_id.insert(path_node_id.begin(),tree[path_node_id.front()].parent_id);
	}
	
	for(int i=0;i<path_node_id.size();i++){
		path.push_back(tree[path_node_id[i]].point);
	}
}
	
//path smoothing algorithm
void VRRT::smoothing(std::vector<Point>& path, double& collision_radius, double step, int iterations, std::vector<Point>& smooth_path){
	
	//use line to replace the broken line between the two point which have max distance
	Point point,temp;
	int new_size,last_size;
	
	//shorten algorithm
	//push point to smooth_path
	std::vector<int> index;
	smooth_path.push_back(path.front());
	
	while( (smooth_path.back().x != path.back().x)||(smooth_path.back().y != path.back().y)||(smooth_path.back().z != path.back().z) ){
		for(int i=1;i<path.size();i++){
			if( collisiong_check(smooth_path.back(),path[path.size()-i], collision_radius) ){
				continue;
			}else{
				if(i==1){		//the last point in path
					smooth_path.push_back(path.back());
				}else{
					smooth_path.push_back(path[path.size()-i]);
				}
				
				break;
			}
		}
	}
	
	new_size = smooth_path.size();
	last_size = new_size;
	while(new_size != last_size){
		
		last_size = new_size;
		
		point.x = smooth_path.front().x;
		point.y = smooth_path.front().y;
		point.z = smooth_path.front().z;
	
		temp.x = smooth_path[1].x;
		temp.y = smooth_path[1].y;
		temp.z = smooth_path[1].z;
	
		for(int i=2;i<smooth_path.size();i++){
			if( collisiong_check(point,smooth_path[i],collision_radius) ){
			
				point.x = temp.x;
				point.y = temp.y;
				point.z = temp.z;
				
				temp.x = smooth_path[i].x;
				temp.y = smooth_path[i].y;
				temp.z = smooth_path[i].z;
				
			}else{
				temp.x = smooth_path[i].x;
				temp.y = smooth_path[i].y;
				temp.z = smooth_path[i].z;
				smooth_path.erase(smooth_path.begin()+i-1);
				i = i - 1;
			}
		}
		new_size = smooth_path.size();
	}
	
	//insert point between two point with specified distance : step
	double dist,dist_x,dist_y,dist_z;
	
	//inseart point
	//step is very important parament for interpolation resoult
	// too small can not eliminate great change
	//too big will change very big even create collision
	for(int i=0;i<smooth_path.size()-1;i++){
		
		temp.x = smooth_path[i].x;
		temp.y = smooth_path[i].y;
		temp.z = smooth_path[i].z;
		
		point.x = smooth_path[i+1].x;
		point.y = smooth_path[i+1].y;
		point.z = smooth_path[i+1].z;
		
		dist = get_Euclidean_distance(temp,point);
		if(dist>step){
			
			dist_x = point.x - temp.x;
			dist_y = point.y - temp.y;
			dist_z = point.z - temp.z;
			
			temp.x = temp.x + step * dist_x / dist;
			temp.y = temp.y + step * dist_y / dist;
			temp.z = temp.z + step * dist_z / dist;
			
			smooth_path.insert(smooth_path.begin()+i+1,temp);
		}
	}

	//2 order lagrange interpolation
	Point first,second1,second2,second3,third;
	
	double point_to_line_dist,dist31,dist21;
	
	//iterations are also very important which can affect the iterations result
	for(int n=0;n<iterations;n++){
		
		//from start to goal
		for(int i=0;i<smooth_path.size()-2;i++){
		
			first.x = smooth_path[i].x;
			first.y = smooth_path[i].y;
			first.z = smooth_path[i].z;
		
			third.x = smooth_path[i+2].x;
			third.y = smooth_path[i+2].y;
			third.z = smooth_path[i+2].z;
		
			point_to_line_dist = get_dist_point_to_line(smooth_path[i+1],first,third);
			if(point_to_line_dist){
				
				dist31 = get_Euclidean_distance(first,third);
				dist21 = get_Euclidean_distance(smooth_path[i+1],first);
				
				dist_x = third.x - first.x;
				dist_y = third.y - first.y;
				dist_z = third.z - first.z;
			
				smooth_path[i+1].x = first.x + dist21 * dist_x / dist31;
				smooth_path[i+1].y = first.y + dist21 * dist_y / dist31;
				smooth_path[i+1].z = first.z + dist21 * dist_z / dist31;

			}
		}

		//from goal to start
		for(int i=smooth_path.size()-1;i>1;i--){
		
			first.x = smooth_path[i].x;
			first.y = smooth_path[i].y;
			first.z = smooth_path[i].z;
		
			third.x = smooth_path[i-2].x;
			third.y = smooth_path[i-2].y;
			third.z = smooth_path[i-2].z;
		
			point_to_line_dist = get_dist_point_to_line(smooth_path[i-1],first,third);
			if(point_to_line_dist){
				
				dist31 = get_Euclidean_distance(first,third);
				dist21 = get_Euclidean_distance(smooth_path[i-1],first);
				
				dist_x = third.x - first.x;
				dist_y = third.y - first.y;
				dist_z = third.z - first.z;
			
				smooth_path[i-1].x = first.x + dist21 * dist_x / dist31;
				smooth_path[i-1].y = first.y + dist21 * dist_y / dist31;
				smooth_path[i-1].z = first.z + dist21 * dist_z / dist31;
			}
		}
	}	
}

void VRRT::get_voronoi_edge(std::vector< std::vector<Node> >& vmap, std::vector< Point >& vedge){
	
	Point p;
	for(int i=0;i<vmap.size();i++){
		for(int j=0;j<vmap[i].size();j++){
			if(vmap[i][j].is_voronoi == true){
				p.x = vmap[i][j].position.x;
				p.y = vmap[i][j].position.y;
				p.z = vmap[i][j].position.z;
				vedge.push_back(p);
			}
		}
	}
}

// void VRRT::random_particles(std::vector< Point >& edge, int& num, double d_x, double d_y, std::vector<Point>& particles){
// 	
// 	int size = edge.size();
// 	Point p;
// 	int range_x = int( d_x  / resolution_ );
// 	int range_y = int( d_y  / resolution_ );
// 	int range_z = int( (max_height_-min_height_) / resolution_ );
// 	
// 	for(int i=0;i<num;i++){
// 		int index = rand() % size;
// 	
// 		p.x = edge[index].x + ( rand() % range_x ) * resolution_ - d_x / 2;
// 		p.y = edge[index].y + ( rand() % range_y ) * resolution_ - d_y /2;
// 		p.z = ( rand() % range_z ) * resolution_ + min_height_;
// 		particles.push_back( p );
// 	}
// 	
// 	pcl::PointXYZ point;
// 	double min_x,max_x,min_y,max_y,min_z,max_z;
// 	
// 	for(int i=0;i<particles.size();i++){
// 		
// 		min_x = particles[i].x - inflation_x_;
// 		max_x = particles[i].x + inflation_x_;
// 		min_y = particles[i].y - inflation_y_;
// 		max_y = particles[i].y + inflation_y_;
// 		min_z = particles[i].z - inflation_z_;
// 		max_z = particles[i].z + inflation_z_;
// 			
// 		for(int j=0;j<octomap_center_cloud_->points.size();j++){
// 			
// 			point = octomap_center_cloud_->points[j];
// 			if( (point.x>min_x)&&(point.x<max_x)&&(point.y>min_y)&&(point.y<max_y)&&(point.z>min_z)&&(point.z<max_z) ){
// 				particles.erase(particles.begin()+i);
// 				i = i - 1;
// 				break;
// 			}
// 		}
// 	}
// }

void VRRT::initializeMarkers(visualization_msgs::Marker& start_marker, visualization_msgs::Marker& goal_marker, visualization_msgs::Marker& particles_marker,
				visualization_msgs::Marker& tree_marker, visualization_msgs::Marker& path_marker, visualization_msgs::Marker& smooth_marker,
				visualization_msgs::Marker& map2D_marker, visualization_msgs::Marker& vedge_marker, std::string& frame_id){
    //init headers
	start_marker.header.frame_id	= goal_marker.header.frame_id		= particles_marker.header.frame_id	= tree_marker.header.frame_id		= path_marker.header.frame_id		= smooth_marker.header.frame_id		= map2D_marker.header.frame_id		= vedge_marker.header.frame_id		= frame_id;
	start_marker.header.stamp	= goal_marker.header.stamp		= particles_marker.header.stamp		= tree_marker.header.stamp		= path_marker.header.stamp		= smooth_marker.header.stamp		= map2D_marker.header.stamp		= vedge_marker.header.stamp		= ros::Time::now();
	start_marker.action		= goal_marker.action			= particles_marker.action		= tree_marker.action			= path_marker.action			= smooth_marker.action			= map2D_marker.action			= vedge_marker.action			= visualization_msgs::Marker::ADD;
	start_marker.pose.orientation.w	= goal_marker.pose.orientation.w	= particles_marker.pose.orientation.w	= tree_marker.pose.orientation.w	= path_marker.pose.orientation.w	= smooth_marker.pose.orientation.w	= map2D_marker.pose.orientation.w	= vedge_marker.pose.orientation.w	= 1.0;
	
    //set namespace
	start_marker.ns		= "start";
	goal_marker.ns		= "goal";
	particles_marker.ns	= "particles";
	tree_marker.ns		= "tree";
	path_marker.ns		= "path";
	smooth_marker.ns	= "smooth_path";
	map2D_marker.ns		= "map_2D";
	vedge_marker.ns		= "v_edge";
	
    //setting id for each marker
	start_marker.id		= 0;
	goal_marker.id		= 0;
	particles_marker.id	= 0;
	tree_marker.id		= 0;
	path_marker.id		= 0;
	smooth_marker.id	= 0;
	map2D_marker.id		= 0;
	vedge_marker.id		= 0;

    //defining types
	start_marker.type	= visualization_msgs::Marker::SPHERE_LIST;
	goal_marker.type	= visualization_msgs::Marker::SPHERE_LIST;
	particles_marker.type	= visualization_msgs::Marker::SPHERE_LIST;
	tree_marker.type	= visualization_msgs::Marker::LINE_LIST;
	path_marker.type	= visualization_msgs::Marker::LINE_STRIP;
	smooth_marker.type	= visualization_msgs::Marker::LINE_STRIP;
	map2D_marker.type	= visualization_msgs::Marker::CUBE_LIST;
	// vedge_marker.type	= visualization_msgs::Marker::CUBE_LIST;
	vedge_marker.type	= visualization_msgs::Marker::SPHERE_LIST;
	
    //setting scale
	start_marker.scale.x	= start_marker.scale.y	= start_marker.scale.z	= 0.4;
	goal_marker.scale.x	= goal_marker.scale.y	= goal_marker.scale.z	= 0.4;
	particles_marker.scale.x  = particles_marker.scale.y  = particles_marker.scale.z  = 0.2;
	tree_marker.scale.x = tree_marker.scale.y = tree_marker.scale.z = 0.02;
	path_marker.scale.x = path_marker.scale.y = path_marker.scale.z = 0.2;
	smooth_marker.scale.x = smooth_marker.scale.y = smooth_marker.scale.z = 0.2;
	map2D_marker.scale.x	= map2D_marker.scale.y	= map2D_marker.scale.z	= 0.1;
	vedge_marker.scale.x	= vedge_marker.scale.y	= vedge_marker.scale.z	= 0.1;
	
    //assigning colors
	start_marker.color.r		= 1.0f;
	goal_marker.color.b		= 1.0f;
	
	particles_marker.color.r	= 0.8f;
	particles_marker.color.g	= 0.4f;

	tree_marker.color.b		= 1.0f;
	
	path_marker.color.r		= 0.6f;
	path_marker.color.g		= 0.2f;
	path_marker.color.b		= 1.0f;
	
	smooth_marker.color.r		= 1.0f;
	
	map2D_marker.color.g		= 1.0f;
	
	vedge_marker.color.r		= 1.0f;
	
	start_marker.color.a = goal_marker.color.a = particles_marker.color.a =  tree_marker.color.a = path_marker.color.a = smooth_marker.color.a = map2D_marker.color.a = vedge_marker.color.a = 1.0f;
}

void VRRT::pub_start(visualization_msgs::Marker& marker, Point& point){
	
	if(marker.points.size())
		marker.points.clear();
	
	geometry_msgs::Point p;
	
	p.x = point.x;
	p.y = point.y;
	p.z = point.z;
	
	marker.points.push_back(p);
	
	start_pub_.publish(marker);
}

void VRRT::pub_goal(visualization_msgs::Marker& marker, Point& point){
	
	if(marker.points.size())
		marker.points.clear();
	
	geometry_msgs::Point p;
	
	p.x = point.x;
	p.y = point.y;
	p.z = point.z;
	
	marker.points.push_back(p);
	
	goal_pub_.publish(marker);
}

void VRRT::pub_particles(visualization_msgs::Marker& marker, std::vector<Point>& particles){
	
	if(marker.points.size())
		marker.points.clear();
	
	geometry_msgs::Point p;
	for(int i=0;i<particles.size();i++){
		p.x = particles[i].x;
		p.y = particles[i].y;
		p.z = particles[i].z;
		marker.points.push_back(p);
	}
	
	particles_pub_.publish(marker);
}

void VRRT::pub_tree(visualization_msgs::Marker& marker, std::vector<node>& tree){
	
	if(marker.points.size())
		marker.points.clear();
	
	std::vector<int> index;
	for(int i=0;i<tree.size();i++){
		index.push_back(i);
	}
	
	geometry_msgs::Point p;
	while(!index.empty()){
		
		p.x = tree[tree[index.back()].parent_id].point.x;
		p.y = tree[tree[index.back()].parent_id].point.y;
		p.z = tree[tree[index.back()].parent_id].point.z;
		marker.points.push_back(p);
	
		p.x = tree[index.back()].point.x;
		p.y = tree[index.back()].point.y;
		p.z = tree[index.back()].point.z;
		marker.points.push_back(p);
		
		index.pop_back();	
	}
	
	tree_pub_.publish(marker);
}

void VRRT::pub_path(visualization_msgs::Marker& marker, std::vector<Point>& path){
	
	if(marker.points.size())
		marker.points.clear();
	
	geometry_msgs::Point p;
	
	for(int i=0;i<path.size();i++){
		p.x = path[i].x;
		p.y = path[i].y;
		p.z = path[i].z;
		marker.points.push_back(p);
	}
	
	path_pub_.publish(marker);
}

void VRRT::pub_smooth_path(visualization_msgs::Marker& marker, std::vector<Point>& smooth_path){
	
	if(marker.points.size())
		marker.points.clear();
	
	geometry_msgs::Point p;
	
	for(int i=0;i<smooth_path.size();i++){
		p.x = smooth_path[i].x;
		p.y = smooth_path[i].y;
		p.z = smooth_path[i].z;
		marker.points.push_back(p);
	}
	
	smooth_path_pub.publish(marker);
}

void VRRT::pub_map2D(visualization_msgs::Marker& marker, std::vector< std::vector<Node> >& vmap){
	
	if(marker.points.size())
		marker.points.clear();
	
	geometry_msgs::Point p;
	
	for(int i=0;i<vmap.size();i++){
		for(int j=0;j<vmap[i].size();j++){
			if(vmap[i][j].is_free == false){
				
				p.x = vmap[i][j].position.x;
				p.y = vmap[i][j].position.y;
				p.z = vmap[i][j].position.z;
				marker.points.push_back(p);
			}
		}
	}
	
	map2D_pub_.publish(marker);
}

void VRRT::pub_vedge(visualization_msgs::Marker& marker, std::vector<Point>& vedge){
	
	if(marker.points.size())
		marker.points.clear();
	
	geometry_msgs::Point p;
	
	for(int i=0;i<vedge.size();i++){
		p.x = vedge[i].x;
		p.y = vedge[i].y;
		p.z = vedge[i].z;
		marker.points.push_back(p);
	}
	
	vedge_pub_.publish(marker);
}

void VRRT::pub_explore(std::vector<Point>& vedge, std::vector< std::vector<bool> >& explore_map){
	
	visualization_msgs::Marker explore;
	
	explore.header.frame_id		= "map";
	explore.header.stamp		= ros::Time::now();
	explore.action			= visualization_msgs::Marker::ADD;
	explore.pose.orientation.w	= 1.0;
	explore.ns			= "explore";
	explore.id			= 0;
	explore.type			= visualization_msgs::Marker::CUBE_LIST;
	explore.scale.x = explore.scale.y = explore.scale.z = 0.1;
	explore.color.a = explore.color.r = explore.color.g = explore.color.b = 1.0f;
	
	geometry_msgs::Point p;
	p.z = vedge[0].z;
	
	for(int i=0;i<explore_map.size();i++){
		for(int j=0;j<explore_map[i].size();j++){
			if(explore_map[i][j] == true){
				p.x = i * resolution_ + min_length_;
				p.y = j * resolution_ + min_width_;
				
				explore.points.push_back(p);
			}
		}
	}
	explore_pub_.publish(explore);
}

void VRRT::pub_2D_point(std::string& frame_id){
	
	pcl::PointCloud<pcl::PointXYZ>::Ptr cloud(cloud_2d_);
	cloud->header.frame_id = frame_id;
	cloud->header.stamp = ros::Time::now().toNSec()/1e3;
	cloud->width = cloud_2d_->width;
	cloud->height = cloud_2d_->height;
	cloud->is_dense = cloud_2d_->is_dense;
	
	cloud2D_pub_.publish(cloud);
}

//subscribe the OctoMap to get the 3d voxel center points
void VRRT::get_point_cloud(const pcl::PointCloud<pcl::PointXYZ>::ConstPtr& pointcloud){
	
	if( boundary_flag_ == false ){
		octomap_center_cloud_->header.frame_id = pointcloud->header.frame_id;
		octomap_center_cloud_->header.stamp = ros::Time::now().toNSec()/1e3;
		octomap_center_cloud_->width = pointcloud->width;
		octomap_center_cloud_->height = pointcloud->height;
		octomap_center_cloud_->is_dense = pointcloud->is_dense;
		octomap_center_cloud_->resize(octomap_center_cloud_->width * octomap_center_cloud_->height);
		for(int i=0;i<pointcloud->points.size();i++){
			octomap_center_cloud_->points[i].x = pointcloud->points[i].x;
			octomap_center_cloud_->points[i].y = pointcloud->points[i].y;
			octomap_center_cloud_->points[i].z = pointcloud->points[i].z;
		}
	
		if( octomap_center_cloud_->points.size() ){
			
			boundary_flag_ = true;
			cout<<"Subscribe to octomap and received "<<octomap_center_cloud_->points.size()<<" center points;"<<endl;
			
			//get the boundary
			for(int i=0;i<octomap_center_cloud_->size();i++){
				if(octomap_center_cloud_->points[i].x < min_length_)
					min_length_ = octomap_center_cloud_->points[i].x;
				if(octomap_center_cloud_->points[i].x > max_length_)
					max_length_ = octomap_center_cloud_->points[i].x;
				if(octomap_center_cloud_->points[i].y < min_width_)
					min_width_ = octomap_center_cloud_->points[i].y;
				if(octomap_center_cloud_->points[i].y > max_width_)
					max_width_ = octomap_center_cloud_->points[i].y;
				if(octomap_center_cloud_->points[i].z < min_height_)
					min_height_ = octomap_center_cloud_->points[i].z;
				if(octomap_center_cloud_->points[i].z > max_height_)
					max_height_ = octomap_center_cloud_->points[i].z;
			}
			
			//get 2d point in specified hight
			if( (hight_<min_height_)||(hight_>max_height_)){
				ROS_ERROR("The hight of 2D points is out of boundary, could not get 2D point !");
			}else{
				//find the aligned hight
				double aligned_hight = 0;
				for(int i=0;i<octomap_center_cloud_->size();i++){
					if( abs(octomap_center_cloud_->points[i].z - hight_) < resolution_ ){
						aligned_hight = octomap_center_cloud_->points[i].z;
						break;
					}
				}
				//get 2D point with aligend hight
				for(int i=0;i<octomap_center_cloud_->size();i++){
					if(octomap_center_cloud_->points[i].z == aligned_hight){
						cloud_2d_->points.push_back(octomap_center_cloud_->points[i]);
					}
				}
				ROS_INFO("Get 2D point successfully, 2D map creating...");
			}
		}
	}
}

//subscribe to get the start point
void VRRT::get_initional_pos(const geometry_msgs::PoseWithCovarianceStampedConstPtr &msg){
	
	if(boundary_flag_){
		
		initional_pos_.x = msg->pose.pose.position.x;
		initional_pos_.y = msg->pose.pose.position.y;
		initional_pos_.z = (max_height_ - min_height_) / 2 + min_height_;
		initional_pos_flag = true;
		
		cout<<"Receive new start point : ("<<initional_pos_.x<<" , "<<initional_pos_.y<<" , "<<initional_pos_.z<<")"<<endl;
		cout<<"Waiting for mission goal..."<<endl;
	}else
		cout<<"Please waiting for reveiving the map pointcloud !"<<endl;
}

//subscribe to get the mission gaol
void VRRT::get_mission_goal(const geometry_msgs::PoseStampedConstPtr &msg){
	
	if(initional_pos_flag){
		
		mission_goal_.x = msg->pose.position.x;
		mission_goal_.y = msg->pose.position.y;
		mission_goal_.z = (max_height_ - min_height_) / 2 + min_height_;
		mission_goal_flag = true;
		
		cout<<"Receive new mission goal : ("<<mission_goal_.x<<" , "<<mission_goal_.y<<" , "<<mission_goal_.z<<")"<<endl;

	}else
		cout<<"Please waiting for reveiving the start point !"<<endl;
}

//collision checking algorithm
bool VRRT::collisiong_check(Point& point1, Point& point2, double& radius){
	
	pcl::PointXYZ point;
	
	Point temp_point;
	
	double min_x,max_x,min_y,max_y,min_z,max_z,dist;
	min_x = min( point1.x , point2.x ) - radius;
	max_x = max( point1.x , point2.x ) + radius;
	min_y = min( point1.y , point2.y ) - radius;
	max_y = max( point1.y , point2.y ) + radius;
	min_z = min( point1.z , point2.z ) - radius;
	max_z = max( point1.z , point2.z ) + radius;
	
	for(int i=0;i<octomap_center_cloud_->points.size();i++){
		point = octomap_center_cloud_->points[i];
		if( (point.x>min_x)&&(point.x<max_x)&&(point.y>min_y)&&(point.y<max_y)&&(point.z>min_z)&&(point.z<max_z) ){
			temp_point.x = point.x;
			temp_point.y = point.y;
			temp_point.z = point.z;
			dist = get_dist_point_to_line(temp_point,point1,point2);
			if( dist < radius )
				return true; //true means collision
		}
	}
	
	return false;
}

//check whether it is out of boundary, true means out and false means inside
bool VRRT::check_boundary(Point& point){
	
	if( (point.x>min_length_)&&(point.x<max_length_)&&(point.y>min_width_)&(point.y<max_width_)&&(point.z>min_height_)&&(point.z<min_height_) )
		return true;
	else
		return false;
}

//measure the square distance between two 2D point
double VRRT::get_Euclidean_distance(int& x1, int& y1, int& x2, int& y2){
	
	double dist = pow( x1 - x2 , 2 ) + pow( y1 - y2 , 2 );
	
	return dist;
}
	
//measure the square distance between two point
double VRRT::get_Euclidean_distance(Point& point1,Point& point2){
	
	double dist = pow( point1.x - point2.x , 2 ) + pow( point1.y - point2.y , 2 ) + pow( point1.z - point2.z , 2 );
	
	return dist;
}

//get the distance from point to line in 3d space, the line represented by two point
double VRRT::get_dist_point_to_line(Point& point, Point& line_point1, Point& line_point2){
	
	double dist1 = get_Euclidean_distance(line_point1,line_point2);
	Point unit,temp,cross;
	unit.x = (line_point2.x - line_point1.x) / dist1;
	unit.y = (line_point2.y - line_point1.y) / dist1;
	unit.z = (line_point2.z - line_point1.z) / dist1;
	
	temp.x = point.x - line_point1.x;
	temp.y = point.y - line_point1.y;
	temp.z = point.z - line_point1.z;
	
	cross.x = temp.y * unit.z - temp.z * unit.y;
	cross.y = temp.z * unit.x - temp.x * unit.z;
	cross.z = temp.x * unit.y - temp.y * unit.x;
	
	double dist = sqrt( pow(cross.x,2)+pow(cross.y,2)+pow(cross.z,2) );
	
	return dist;
}

} //end namespace
}