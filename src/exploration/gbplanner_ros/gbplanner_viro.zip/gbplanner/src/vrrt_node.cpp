#include <ros/ros.h>

#include <iostream>
#include<iomanip>
#include<fstream>
#include <string>

#include <gbplanner/vrrt.h>
#include <gbplanner/dynamicvoronoi.h>

using namespace std;
using namespace explorer::gbplanner;

int main(int argc, char** argv){
	
	ros::init(argc,argv,"voronoi_guide_rrt_node");
	
	ros::NodeHandle n;
	
	std::string frame_id;
	int particles_num,smooth_interations;
	double particles_rx,particles_ry,particle_limited_min_z,particle_limited_max_z,collision_radius,interpolation_step,node_search_radius_x,node_search_radius_y;
	string examination_resultfile_name;
	
	n.param<std::string>("/vrrt/examination_resultfile_name", examination_resultfile_name, "/home/luan/workspace/catkin/src/navigation_3d/voronoi_guide_rrt/examination/examination_result.txt");
	
	n.param<std::string>("/vrrt/frame_id", frame_id, "map");
	n.param<int>("/vrrt/particles_number", particles_num, 10);		// the number of random particles in each iteration
	n.param<double>("vrrt/particles_radius_x", particles_rx, 0.5);
	n.param<double>("vrrt/particles_radius_y", particles_ry, 0.5);
	n.param<double>("vrrt/particles_min_h", particle_limited_min_z, 0);
	n.param<double>("vrrt/particles_max_h", particle_limited_max_z, 1);
	n.param<double>("vrrt/collision_radius", collision_radius, 0.4);
	n.param<double>("vrrt/smooth_interpolation_step", interpolation_step, 0.1);
	n.param<int>("vrrt/smooth_interations", smooth_interations, 10);
	n.param<double>("vrrt/node_search_radius_x", node_search_radius_x, 0.5);
	n.param<double>("vrrt/node_search_radius_y", node_search_radius_y, 0.5);
	
	VRRT vrrt;	//create object
	vector< vector<Node> > vmap;
	vector< vector<bool> > explored_map;
	vector<node> tree;
	vector< Point > particles,vedge,path,smooth_path;
	vector< pair<int,int> > node_temp,branch;
	pair<int,int> N;
	Point start,last_start,goal,best_particle;
	int parent_id;
	
	visualization_msgs::Marker start_marker,goal_marker,particles_marker,tree_marker,path_marker,smooth_marker,map2D_marker,vedge_marker;
	
	vrrt.initializeMarkers(start_marker,goal_marker,particles_marker,tree_marker,path_marker,smooth_marker,map2D_marker,vedge_marker,frame_id);
	
	bool goal_start_show_flag = false;
	bool start_process_flag = false;
	bool reach_goal_flag = false;
	bool new_branch_flag = false;
	bool get_best_particle_flag = false;
	bool get_best_node_flag = false;
	
	ros::Rate loop_rate(500);
	
// 	int counter = 0;
	int write_counter = 0;
	ros::Time time;
	ros::Duration duration;
	ofstream f_write;
	
	
	while (ros::ok())
	{
		
		if(vrrt.init_vmap(vmap)){
			
			DynamicVoronoi voronoi;
			voronoi.initializeMap(vmap);
			voronoi.brushfire();
			voronoi.prune();
			
			for (int i = 0; i < vmap.size(); i++)
			{
				for (int j = 0; j < vmap[i].size(); j++)
				{
					if (voronoi.isVoronoi(i, j))
					{
						vmap[i][j].is_voronoi = true;		//true means edge
					}else
						vmap[i][j].is_voronoi = false;		//false means the point inside
				}
			}
			vrrt.get_voronoi_edge(vmap,vedge);
			vrrt.pub_map2D(map2D_marker,vmap);
			vrrt.pub_vedge(vedge_marker,vedge);
			ROS_INFO("Create voronoi diagram successfully, waiting for set initional pose...");
		}
		
		if(vrrt.initional_pos_flag){
			
			start = vrrt.get_start_point();
			
			if( (start.x != last_start.x)&&(start.y != last_start.y)&&(start.z != last_start.z) ){
				
				start_process_flag = false;
				
				tree.clear();
				particles.clear();
				path.clear();
				smooth_path.clear();
				node_temp.clear();
				branch.clear();
				
				last_start.x = start.x;
				last_start.y = start.y;
				last_start.z = start.z;
			}
			
			vrrt.pub_start(start_marker,start);
			if(goal_start_show_flag){
				vrrt.pub_goal(goal_marker,goal);
			}
			vrrt.pub_tree(tree_marker,tree);
			vrrt.pub_path(path_marker,path);
			vrrt.pub_smooth_path(smooth_marker,smooth_path);
			vrrt.pub_map2D(map2D_marker,vmap);
			vrrt.pub_vedge(vedge_marker,vedge);
			vrrt.pub_explore(vedge,explored_map);
			vrrt.pub_2D_point(frame_id);
		}
		
		if(vrrt.mission_goal_flag){
			
			tree.clear();
			particles.clear();
			path.clear();
			smooth_path.clear();
			node_temp.clear();
			branch.clear();
			
			goal = vrrt.get_goal_point();
			vrrt.pub_goal(goal_marker,goal);
			
			vrrt.mission_goal_flag = false;
			goal_start_show_flag = true;
			
			vrrt.init_explore_map(vmap,explored_map);
			vrrt.pub_explore(vedge,explored_map);
			
			start_process_flag = true;
			new_branch_flag = false;
			reach_goal_flag = false;
			
			vrrt.set_to_tree(tree,start,0);
			N = vrrt.find_v_node(start,vmap);
			
			ROS_INFO("Random tree growing...");
			
			
			time = ros::Time::now();
		}
		
		if(start_process_flag){
			
			vrrt.remove_node_from_temp(N,node_temp);
			
			particles = vrrt.get_particles(N,particles_num,particles_rx,particles_ry,particle_limited_min_z,particle_limited_max_z);
			
			vrrt.pub_particles(particles_marker,particles);
			
			get_best_particle_flag = vrrt.get_best_particle(tree,particles,new_branch_flag,collision_radius,best_particle,parent_id);
			
			if(!get_best_particle_flag){
				if(node_temp.size()){
					
					get_best_node_flag = vrrt.get_best_node(node_temp,goal,N);
					
					if(!get_best_node_flag){
						
						node_temp.clear();
						
						if(branch.size()){
							
							new_branch_flag = true;		//if can not find a valid voronoi edge node, then find a new branch from vector branch
							
							if( vrrt.get_best_node(branch,goal,N) ){
								vrrt.remove_node_from_temp(N,branch);
							}else{
								ROS_ERROR("Could not find a valid global path !");
								ROS_INFO("You may want to chenge the start or goal, and try again !");
								start_process_flag = false;
								
								
								vrrt.mission_goal_flag = true;
							}
						}else{
							ROS_ERROR("Could not find a valid global path !");
							ROS_INFO("You may want to chenge the start or goal, and try again !");
							start_process_flag = false;
							
							
							vrrt.mission_goal_flag = true;
						}
					}
				}else{
					if(branch.size()){
						
						new_branch_flag = true;		//if can not find a valid voronoi edge node, then find a new branch from vector branch
						
						if( vrrt.get_best_node(branch,goal,N) ){
							vrrt.remove_node_from_temp(N,branch);
						}else{
							ROS_ERROR("Could not find a valid global path !");
							ROS_INFO("You may want to chenge the start or goal, and try again !");
							start_process_flag = false;
							
							
							vrrt.mission_goal_flag = true;
						}
					}else{
						ROS_ERROR("Could not find a valid global path !");
						ROS_INFO("You may want to chenge the start or goal, and try again !");
						start_process_flag = false;
						
						
						vrrt.mission_goal_flag = true;
					}
				}
			}else{
				
				new_branch_flag = false;	//if best particle exist, there is a nacessary to keep moving forward
				
				vrrt.set_to_tree(tree,best_particle,parent_id);
				
				reach_goal_flag = vrrt.is_finish(tree,goal,collision_radius);
				
				if(reach_goal_flag){
					
					vrrt.set_to_tree(tree,goal,tree.back().node_id);
					
					vrrt.get_final_path(tree,path);
					
					vrrt.smoothing(path,collision_radius,interpolation_step,smooth_interations,smooth_path);
					
					start_process_flag = false;
					
					ROS_INFO("A valid path founded !");
					
					duration = ros::Time::now() - time;
					cout<<"The iterations : "<<tree.size()<<endl;
					cout<<"The size of random tree is : "<<tree.size()<<endl;
					cout<<"The time consumed : "<<duration<<endl;
					
					f_write.open(examination_resultfile_name.c_str(),ios::in|ios::app);
					if(f_write.is_open()){
						f_write<<write_counter<<" : "<<tree.size()<<" , "<<duration<<endl;
						write_counter++;
						if(write_counter == 100)
							return 0;
					}
					f_write.close();
					vrrt.mission_goal_flag = true;
					
					
					
				}else{
					
					vrrt.set_node_to_branch(branch,node_temp);
					
					node_temp = vrrt.get_v_node(N,vmap,explored_map,node_search_radius_x,node_search_radius_y);
					
					get_best_node_flag = vrrt.get_best_node(node_temp,goal,N);
					
					if(!get_best_node_flag){
						
						node_temp.clear();
						
						if(branch.size()){
							
							new_branch_flag = true;		//if can not find a valid voronoi edge node, then find a new branch from vector branch
							
							if( vrrt.get_best_node(branch,goal,N) ){
								vrrt.remove_node_from_temp(N,branch);
							}else{
								ROS_ERROR("Could not find a valid global path !");
								ROS_INFO("You may want to chenge the start or goal, and try again !");
								start_process_flag = false;
								
								
// 								vrrt.mission_goal_flag = true;
							}
							
						}else{
							ROS_ERROR("Could not find a valid global path !");
							ROS_INFO("You may want to chenge the start or goal, and try again !");
							start_process_flag = false;
							
							
// 							vrrt.mission_goal_flag = true;
						}
					}
				}
			}
		}
		ros::spinOnce();
	}
	
	return 0;
}